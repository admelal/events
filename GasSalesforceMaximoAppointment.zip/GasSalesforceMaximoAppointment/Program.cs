using Azure.Identity;
using Azure.Messaging.ServiceBus;
using Azure.Storage.Blobs;
using GasSalesforceMaximoAppointment.Options;
using GasSalesforceMaximoAppointment.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

var builder = FunctionsApplication.CreateBuilder(args);

builder.ConfigureFunctionsWorkerDefaults();

builder.Services
    .AddOptions<SalesforceOptions>()
    .Bind(builder.Configuration.GetSection(SalesforceOptions.SectionName))
    .ValidateDataAnnotations()
    .ValidateOnStart();

builder.Services
    .AddOptions<ServiceBusOptions>()
    .Bind(builder.Configuration.GetSection(ServiceBusOptions.SectionName))
    .ValidateDataAnnotations()
    .ValidateOnStart();

builder.Services
    .AddOptions<ReplayStoreOptions>()
    .Bind(builder.Configuration.GetSection(ReplayStoreOptions.SectionName))
    .ValidateDataAnnotations()
    .ValidateOnStart();

builder.Services
    .AddOptions<MaximoOptions>()
    .Bind(builder.Configuration.GetSection(MaximoOptions.SectionName))
    .ValidateDataAnnotations()
    .ValidateOnStart();

builder.Services.AddSingleton(new DefaultAzureCredential());

builder.Services.AddSingleton(sp =>
{
    var options = sp.GetRequiredService<IOptions<ServiceBusOptions>>().Value;
    return new ServiceBusClient(options.FullyQualifiedNamespace, sp.GetRequiredService<DefaultAzureCredential>());
});

builder.Services.AddSingleton(sp =>
{
    var options = sp.GetRequiredService<IOptions<ReplayStoreOptions>>().Value;
    return new BlobServiceClient(new Uri(options.BlobServiceUri), sp.GetRequiredService<DefaultAzureCredential>());
});

builder.Services.AddHttpClient<ISalesforceAuthService, SalesforceAuthService>();
builder.Services.AddHttpClient<IMaximoService, MaximoService>((sp, client) =>
{
    var options = sp.GetRequiredService<IOptions<MaximoOptions>>().Value;
    client.BaseAddress = new Uri(options.BaseUrl);
    client.Timeout = TimeSpan.FromSeconds(options.TimeoutSeconds);
});

builder.Services.AddSingleton<IReplayCheckpointStore, BlobReplayCheckpointStore>();
builder.Services.AddSingleton<IValveInspectionEventPublisher, ValveInspectionEventPublisher>();
builder.Services.AddSingleton<IAvroEventDecoder, AvroEventDecoder>();
builder.Services.AddSingleton<ISalesforcePubSubService, SalesforcePubSubService>();

await builder.Build().RunAsync();
