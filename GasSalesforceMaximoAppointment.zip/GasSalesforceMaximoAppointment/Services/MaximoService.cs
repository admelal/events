using System.Net;
using System.Net.Http.Json;
using GasSalesforceMaximoAppointment.Models;
using GasSalesforceMaximoAppointment.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace GasSalesforceMaximoAppointment.Services;

public sealed class MaximoService : IMaximoService
{
    private readonly HttpClient _httpClient;
    private readonly MaximoOptions _options;
    private readonly ILogger<MaximoService> _logger;

    public MaximoService(HttpClient httpClient, IOptions<MaximoOptions> options, ILogger<MaximoService> logger)
    {
        _httpClient = httpClient;
        _options = options.Value;
        _logger = logger;
    }

    public async Task SendValveInspectionAsync(
        SalesforceEventEnvelope valveInspectionEvent,
        CancellationToken cancellationToken)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, _options.ValveInspectionPath)
        {
            Content = JsonContent.Create(valveInspectionEvent.Payload)
        };

        request.Headers.TryAddWithoutValidation("x-correlation-id", valveInspectionEvent.CorrelationId);
        request.Headers.TryAddWithoutValidation("Idempotency-Key", valveInspectionEvent.EventUuid);

        if (!string.IsNullOrWhiteSpace(_options.ApiKey))
        {
            request.Headers.TryAddWithoutValidation(_options.ApiKeyHeaderName, _options.ApiKey);
        }

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        if (response.IsSuccessStatusCode)
        {
            _logger.LogInformation(
                "Sent valve-inspection event {EventUuid} to Maximo; StatusCode={StatusCode}; CorrelationId={CorrelationId}",
                valveInspectionEvent.EventUuid,
                (int)response.StatusCode,
                valveInspectionEvent.CorrelationId);
            return;
        }

        var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);
        var message = $"Maximo returned HTTP {(int)response.StatusCode}: {Truncate(responseBody, 2000)}";

        if (IsRetryable(response.StatusCode))
        {
            throw new MaximoTransientException(message, response.StatusCode);
        }

        throw new MaximoPermanentException(message, response.StatusCode);
    }

    private static bool IsRetryable(HttpStatusCode statusCode) => statusCode is
        HttpStatusCode.RequestTimeout or
        HttpStatusCode.TooManyRequests or
        HttpStatusCode.InternalServerError or
        HttpStatusCode.BadGateway or
        HttpStatusCode.ServiceUnavailable or
        HttpStatusCode.GatewayTimeout;

    private static string Truncate(string value, int maxLength) =>
        value.Length <= maxLength ? value : value[..maxLength];
}

public sealed class MaximoTransientException : Exception
{
    public MaximoTransientException(string message, HttpStatusCode statusCode) : base(message) => StatusCode = statusCode;
    public HttpStatusCode StatusCode { get; }
}

public sealed class MaximoPermanentException : Exception
{
    public MaximoPermanentException(string message, HttpStatusCode statusCode) : base(message) => StatusCode = statusCode;
    public HttpStatusCode StatusCode { get; }
}
