namespace GasSalesforceMaximoAppointment.Services;

public interface IReplayCheckpointStore
{
    Task<byte[]?> GetAsync(CancellationToken cancellationToken);
    Task SaveAsync(byte[] replayId, CancellationToken cancellationToken);
}
