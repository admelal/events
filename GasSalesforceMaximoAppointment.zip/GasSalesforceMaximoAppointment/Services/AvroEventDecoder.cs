using Avro;
using Avro.Generic;
using Avro.IO;

namespace GasSalesforceMaximoAppointment.Services;

public sealed class AvroEventDecoder : IAvroEventDecoder
{
    public IReadOnlyDictionary<string, object?> Decode(byte[] payload, string schemaJson)
    {
        var schema = Schema.Parse(schemaJson);
        var reader = new GenericDatumReader<GenericRecord>(schema, schema);

        using var stream = new MemoryStream(payload, writable: false);
        var decoder = new BinaryDecoder(stream);
        var record = reader.Read(default!, decoder);

        return record.Schema.Fields.ToDictionary(
            field => field.Name,
            field => Normalize(record[field.Name]),
            StringComparer.Ordinal);
    }

    private static object? Normalize(object? value) => value switch
    {
        null => null,
        GenericRecord nested => nested.Schema.Fields.ToDictionary(
            field => field.Name,
            field => Normalize(nested[field.Name]),
            StringComparer.Ordinal),
        IDictionary<string, object> map => map.ToDictionary(
            entry => entry.Key,
            entry => Normalize(entry.Value),
            StringComparer.Ordinal),
        System.Collections.IDictionary map => map.Keys.Cast<object>().ToDictionary(
            key => key.ToString() ?? string.Empty,
            key => Normalize(map[key]),
            StringComparer.Ordinal),
        byte[] bytes => Convert.ToBase64String(bytes),
        IEnumerable<object> items => items.Select(Normalize).ToArray(),
        System.Collections.IEnumerable items when value is not string =>
            items.Cast<object?>().Select(Normalize).ToArray(),
        _ => value
    };
}
