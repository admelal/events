namespace GasSalesforceMaximoAppointment.Services;

public interface IAvroEventDecoder
{
    IReadOnlyDictionary<string, object?> Decode(byte[] payload, string schemaJson);
}
