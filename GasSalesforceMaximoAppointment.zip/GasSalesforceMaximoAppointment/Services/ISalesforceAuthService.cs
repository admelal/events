using GasSalesforceMaximoAppointment.Models;

namespace GasSalesforceMaximoAppointment.Services;

public interface ISalesforceAuthService
{
    Task<SalesforceTokenResponse> GetAccessTokenAsync(CancellationToken cancellationToken);
}
