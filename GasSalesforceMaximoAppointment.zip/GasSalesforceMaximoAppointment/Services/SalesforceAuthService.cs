using System.Net.Http.Json;
using GasSalesforceMaximoAppointment.Models;
using GasSalesforceMaximoAppointment.Options;
using Microsoft.Extensions.Options;

namespace GasSalesforceMaximoAppointment.Services;

public sealed class SalesforceAuthService : ISalesforceAuthService
{
    private static readonly TimeSpan TokenLifetime = TimeSpan.FromMinutes(10);
    private readonly HttpClient _httpClient;
    private readonly SalesforceOptions _options;
    private readonly SemaphoreSlim _lock = new(1, 1);
    private SalesforceTokenResponse? _cachedToken;
    private DateTimeOffset _expiresAtUtc;

    public SalesforceAuthService(HttpClient httpClient, IOptions<SalesforceOptions> options)
    {
        _httpClient = httpClient;
        _options = options.Value;
    }

    public async Task<SalesforceTokenResponse> GetAccessTokenAsync(CancellationToken cancellationToken)
    {
        if (_cachedToken is not null && DateTimeOffset.UtcNow < _expiresAtUtc)
        {
            return _cachedToken;
        }

        await _lock.WaitAsync(cancellationToken);
        try
        {
            if (_cachedToken is not null && DateTimeOffset.UtcNow < _expiresAtUtc)
            {
                return _cachedToken;
            }

            using var request = new HttpRequestMessage(HttpMethod.Post, _options.TokenUrl)
            {
                Content = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    ["grant_type"] = "client_credentials",
                    ["client_id"] = _options.ClientId,
                    ["client_secret"] = _options.ClientSecret
                })
            };

            using var response = await _httpClient.SendAsync(request, cancellationToken);
            response.EnsureSuccessStatusCode();

            _cachedToken = await response.Content.ReadFromJsonAsync<SalesforceTokenResponse>(cancellationToken)
                ?? throw new InvalidOperationException("Salesforce returned an empty OAuth response.");

            _expiresAtUtc = DateTimeOffset.UtcNow.Add(TokenLifetime);
            return _cachedToken;
        }
        finally
        {
            _lock.Release();
        }
    }
}
