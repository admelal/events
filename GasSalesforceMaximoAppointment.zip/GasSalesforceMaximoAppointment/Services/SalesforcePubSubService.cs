using System.Collections.Concurrent;
using Eventbus.V1;
using GasSalesforceMaximoAppointment.Models;
using GasSalesforceMaximoAppointment.Options;
using Google.Protobuf;
using Grpc.Core;
using Grpc.Net.Client;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace GasSalesforceMaximoAppointment.Services;

public sealed class SalesforcePubSubService : ISalesforcePubSubService
{
    private readonly ISalesforceAuthService _authService;
    private readonly IReplayCheckpointStore _checkpointStore;
    private readonly IAvroEventDecoder _decoder;
    private readonly IValveInspectionEventPublisher _publisher;
    private readonly SalesforceOptions _options;
    private readonly ILogger<SalesforcePubSubService> _logger;
    private readonly ConcurrentDictionary<string, string> _schemaCache = new(StringComparer.Ordinal);

    public SalesforcePubSubService(
        ISalesforceAuthService authService,
        IReplayCheckpointStore checkpointStore,
        IAvroEventDecoder decoder,
        IValveInspectionEventPublisher publisher,
        IOptions<SalesforceOptions> options,
        ILogger<SalesforcePubSubService> logger)
    {
        _authService = authService;
        _checkpointStore = checkpointStore;
        _decoder = decoder;
        _publisher = publisher;
        _options = options.Value;
        _logger = logger;
    }

    public async Task SubscribeAsync(CancellationToken cancellationToken)
    {
        var retryDelay = TimeSpan.FromSeconds(2);

        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                await RunSubscriptionAsync(cancellationToken);
                retryDelay = TimeSpan.FromSeconds(2);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                return;
            }
            catch (Exception exception)
            {
                _logger.LogError(exception,
                    "Salesforce Pub/Sub stream failed. Reconnecting in {DelaySeconds} seconds",
                    retryDelay.TotalSeconds);
                await Task.Delay(retryDelay, cancellationToken);
                retryDelay = TimeSpan.FromSeconds(Math.Min(retryDelay.TotalSeconds * 2, 60));
            }
        }
    }

    private async Task RunSubscriptionAsync(CancellationToken cancellationToken)
    {
        var token = await _authService.GetAccessTokenAsync(cancellationToken);
        var headers = new Metadata
        {
            { "accesstoken", token.AccessToken },
            { "instanceurl", token.InstanceUrl },
            { "tenantid", _options.TenantId }
        };

        using var channel = GrpcChannel.ForAddress(_options.PubSubEndpoint);
        var client = new PubSub.PubSubClient(channel);

        var topic = await client.GetTopicAsync(
            new TopicRequest { TopicName = _options.ChannelName },
            headers,
            cancellationToken: cancellationToken);

        if (!topic.CanSubscribe)
        {
            throw new UnauthorizedAccessException($"Salesforce user cannot subscribe to {_options.ChannelName}.");
        }

        var checkpoint = await _checkpointStore.GetAsync(cancellationToken);
        using var call = client.Subscribe(headers, cancellationToken: cancellationToken);

        var initialRequest = new FetchRequest
        {
            TopicName = _options.ChannelName,
            NumRequested = _options.BatchSize,
            ReplayPreset = checkpoint is null ? ReplayPreset.Latest : ReplayPreset.Custom
        };

        if (checkpoint is not null)
        {
            initialRequest.ReplayId = ByteString.CopyFrom(checkpoint);
        }

        await call.RequestStream.WriteAsync(initialRequest, cancellationToken);
        _logger.LogInformation(
            "Subscribed to Salesforce channel {ChannelName} from {ReplayPosition}",
            _options.ChannelName,
            checkpoint is null ? "latest" : Convert.ToBase64String(checkpoint));

        await foreach (var response in call.ResponseStream.ReadAllAsync(cancellationToken))
        {
            foreach (var consumerEvent in response.Events)
            {
                await ProcessEventAsync(client, headers, consumerEvent, response.RpcId, cancellationToken);
            }

            if (response.Events.Count > 0)
            {
                await call.RequestStream.WriteAsync(
                    new FetchRequest { NumRequested = response.Events.Count },
                    cancellationToken);
            }
        }
    }

    private async Task ProcessEventAsync(
        PubSub.PubSubClient client,
        Metadata headers,
        ConsumerEvent consumerEvent,
        string rpcId,
        CancellationToken cancellationToken)
    {
        var schemaId = consumerEvent.Event.SchemaId;
        var schemaJson = await GetSchemaAsync(client, headers, schemaId, cancellationToken);
        var payload = _decoder.Decode(consumerEvent.Event.Payload.ToByteArray(), schemaJson);
        var replayBytes = consumerEvent.ReplayId.ToByteArray();
        var replayId = Convert.ToBase64String(replayBytes);

        var eventUuid = GetString(payload, "EventUuid")
            ?? GetString(payload, "EventUuid__c")
            ?? consumerEvent.Event.Id
            ?? replayId;

        var correlationId = GetString(payload, "CorrelationId__c")
            ?? GetString(payload, "CorrelationId")
            ?? eventUuid;

        var envelope = new SalesforceEventEnvelope(
            consumerEvent.Event.Id,
            eventUuid,
            replayId,
            schemaId,
            _options.ChannelName,
            correlationId,
            DateTimeOffset.UtcNow,
            payload);

        await _publisher.PublishAsync(envelope, cancellationToken);
        await _checkpointStore.SaveAsync(replayBytes, cancellationToken);

        _logger.LogInformation(
            "Queued Salesforce event {EventUuid}; ReplayId={ReplayId}; CorrelationId={CorrelationId}; RpcId={RpcId}",
            eventUuid,
            replayId,
            correlationId,
            rpcId);
    }

    private async Task<string> GetSchemaAsync(
        PubSub.PubSubClient client,
        Metadata headers,
        string schemaId,
        CancellationToken cancellationToken)
    {
        if (_schemaCache.TryGetValue(schemaId, out var cached))
        {
            return cached;
        }

        var schema = await client.GetSchemaAsync(
            new SchemaRequest { SchemaId = schemaId },
            headers,
            cancellationToken: cancellationToken);

        _schemaCache[schemaId] = schema.SchemaJson;
        return schema.SchemaJson;
    }

    private static string? GetString(IReadOnlyDictionary<string, object?> values, string key) =>
        values.TryGetValue(key, out var value) ? value?.ToString() : null;
}
