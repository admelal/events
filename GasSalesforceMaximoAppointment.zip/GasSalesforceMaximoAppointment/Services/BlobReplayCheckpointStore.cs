using Azure.Storage.Blobs;
using GasSalesforceMaximoAppointment.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace GasSalesforceMaximoAppointment.Services;

public sealed class BlobReplayCheckpointStore : IReplayCheckpointStore
{
    private readonly BlobContainerClient _container;
    private readonly string _blobName;
    private readonly ILogger<BlobReplayCheckpointStore> _logger;
    private readonly SemaphoreSlim _initializationLock = new(1, 1);
    private bool _initialized;

    public BlobReplayCheckpointStore(
        BlobServiceClient blobServiceClient,
        IOptions<ReplayStoreOptions> options,
        ILogger<BlobReplayCheckpointStore> logger)
    {
        _container = blobServiceClient.GetBlobContainerClient(options.Value.ContainerName);
        _blobName = options.Value.BlobName;
        _logger = logger;
    }

    public async Task<byte[]?> GetAsync(CancellationToken cancellationToken)
    {
        await EnsureContainerAsync(cancellationToken);
        var blob = _container.GetBlobClient(_blobName);
        if (!await blob.ExistsAsync(cancellationToken))
        {
            return null;
        }

        var content = await blob.DownloadContentAsync(cancellationToken);
        return Convert.FromBase64String(content.Value.Content.ToString());
    }

    public async Task SaveAsync(byte[] replayId, CancellationToken cancellationToken)
    {
        await EnsureContainerAsync(cancellationToken);
        var value = Convert.ToBase64String(replayId);
        await _container.GetBlobClient(_blobName).UploadAsync(BinaryData.FromString(value), overwrite: true, cancellationToken);
        _logger.LogDebug("Saved Salesforce replay checkpoint {ReplayId}", value);
    }

    private async Task EnsureContainerAsync(CancellationToken cancellationToken)
    {
        if (_initialized) return;

        await _initializationLock.WaitAsync(cancellationToken);
        try
        {
            if (!_initialized)
            {
                await _container.CreateIfNotExistsAsync(cancellationToken: cancellationToken);
                _initialized = true;
            }
        }
        finally
        {
            _initializationLock.Release();
        }
    }
}
