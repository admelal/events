using GasSalesforceMaximoAppointment.Models;

namespace GasSalesforceMaximoAppointment.Services;

public interface IMaximoService
{
    Task SendValveInspectionAsync(SalesforceEventEnvelope valveInspectionEvent, CancellationToken cancellationToken);
}
