using Azure.Messaging.ServiceBus;
using GasSalesforceMaximoAppointment.Models;
using GasSalesforceMaximoAppointment.Options;
using Microsoft.Extensions.Options;

namespace GasSalesforceMaximoAppointment.Services;

public sealed class ValveInspectionEventPublisher : IValveInspectionEventPublisher, IAsyncDisposable
{
    private readonly ServiceBusSender _sender;

    public ValveInspectionEventPublisher(ServiceBusClient client, IOptions<ServiceBusOptions> options)
    {
        _sender = client.CreateSender(options.Value.TopicName);
    }

    public Task PublishAsync(SalesforceEventEnvelope envelope, CancellationToken cancellationToken)
    {
        var message = new ServiceBusMessage(BinaryData.FromObjectAsJson(envelope))
        {
            MessageId = envelope.EventUuid,
            CorrelationId = envelope.CorrelationId,
            Subject = "NG_Appointment_Event__e",
            ContentType = "application/json"
        };

        message.ApplicationProperties["sourceSystem"] = "Salesforce";
        message.ApplicationProperties["targetSystem"] = "Maximo";
        message.ApplicationProperties["replayId"] = envelope.ReplayId;
        message.ApplicationProperties["schemaId"] = envelope.SchemaId;

        return _sender.SendMessageAsync(message, cancellationToken);
    }

    public ValueTask DisposeAsync() => _sender.DisposeAsync();
}
