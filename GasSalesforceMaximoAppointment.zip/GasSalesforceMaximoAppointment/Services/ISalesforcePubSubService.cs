namespace GasSalesforceMaximoAppointment.Services;

public interface ISalesforcePubSubService
{
    Task SubscribeAsync(CancellationToken cancellationToken);
}
