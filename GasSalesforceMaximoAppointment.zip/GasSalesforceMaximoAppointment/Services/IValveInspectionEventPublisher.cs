using GasSalesforceMaximoAppointment.Models;

namespace GasSalesforceMaximoAppointment.Services;

public interface IValveInspectionEventPublisher
{
    Task PublishAsync(SalesforceEventEnvelope envelope, CancellationToken cancellationToken);
}
