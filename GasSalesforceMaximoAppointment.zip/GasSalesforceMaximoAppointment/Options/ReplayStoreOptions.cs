using System.ComponentModel.DataAnnotations;

namespace GasSalesforceMaximoAppointment.Options;

public sealed class ReplayStoreOptions
{
    public const string SectionName = "ReplayStore";

    [Required] public string BlobServiceUri { get; init; } = string.Empty;
    [Required] public string ContainerName { get; init; } = "salesforce-replay";
    [Required] public string BlobName { get; init; } = "ng-appointment-event.replay";
}
