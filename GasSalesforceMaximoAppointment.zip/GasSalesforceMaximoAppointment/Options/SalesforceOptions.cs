using System.ComponentModel.DataAnnotations;

namespace GasSalesforceMaximoAppointment.Options;

public sealed class SalesforceOptions
{
    public const string SectionName = "Salesforce";

    [Required] public string TokenUrl { get; init; } = string.Empty;
    [Required] public string ClientId { get; init; } = string.Empty;
    [Required] public string ClientSecret { get; init; } = string.Empty;
    [Required] public string TenantId { get; init; } = string.Empty;
    [Required] public string PubSubEndpoint { get; init; } = "https://api.pubsub.salesforce.com:7443";
    [Required] public string ChannelName { get; init; } = "/event/NG_Appointment_Event__e";
    [Range(1, 100)] public int BatchSize { get; init; } = 10;
}
