using System.ComponentModel.DataAnnotations;

namespace GasSalesforceMaximoAppointment.Options;

public sealed class MaximoOptions
{
    public const string SectionName = "Maximo";

    [Required] public string BaseUrl { get; init; } = string.Empty;
    [Required] public string ValveInspectionPath { get; init; } = string.Empty;
    public string? ApiKey { get; init; }
    public string ApiKeyHeaderName { get; init; } = "apikey";
    [Range(1, 300)] public int TimeoutSeconds { get; init; } = 60;
}
