using System.ComponentModel.DataAnnotations;

namespace GasSalesforceMaximoAppointment.Options;

public sealed class ServiceBusOptions
{
    public const string SectionName = "ServiceBus";

    [Required] public string FullyQualifiedNamespace { get; init; } = string.Empty;
    [Required] public string TopicName { get; init; } = string.Empty;
}
