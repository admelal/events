using Azure.Messaging.ServiceBus;
using GasSalesforceMaximoAppointment.Models;
using GasSalesforceMaximoAppointment.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace GasSalesforceMaximoAppointment.Functions;

public sealed class ValveInspectionEventSendToMaximo
{
    private readonly IMaximoService _maximoService;
    private readonly ILogger<ValveInspectionEventSendToMaximo> _logger;

    public ValveInspectionEventSendToMaximo(
        IMaximoService maximoService,
        ILogger<ValveInspectionEventSendToMaximo> logger)
    {
        _maximoService = maximoService;
        _logger = logger;
    }

    [Function(nameof(ValveInspectionEventSendToMaximo))]
    public async Task RunAsync(
        [ServiceBusTrigger(
            "%ServiceBus__TopicName%",
            "%ServiceBusSubscriptionName%",
            Connection = "ServiceBusConnection")]
        ServiceBusReceivedMessage message,
        ServiceBusMessageActions messageActions,
        CancellationToken cancellationToken)
    {
        var valveInspectionEvent = message.Body.ToObjectFromJson<SalesforceEventEnvelope>()
            ?? throw new InvalidOperationException("Service Bus message body is empty.");

        try
        {
            await _maximoService.SendValveInspectionAsync(valveInspectionEvent, cancellationToken);
            await messageActions.CompleteMessageAsync(message, cancellationToken);
        }
        catch (MaximoPermanentException exception)
        {
            _logger.LogError(exception,
                "Dead-lettering non-retryable Maximo request; EventUuid={EventUuid}; CorrelationId={CorrelationId}",
                valveInspectionEvent.EventUuid,
                valveInspectionEvent.CorrelationId);

            await messageActions.DeadLetterMessageAsync(
                message,
                "MAXIMO_NON_RETRYABLE_ERROR",
                exception.Message,
                cancellationToken);
        }
    }
}
