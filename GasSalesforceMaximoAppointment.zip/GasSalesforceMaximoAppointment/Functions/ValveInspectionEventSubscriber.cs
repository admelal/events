using GasSalesforceMaximoAppointment.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace GasSalesforceMaximoAppointment.Functions;

public sealed class ValveInspectionEventSubscriber
{
    private readonly ISalesforcePubSubService _pubSubService;
    private readonly ILogger<ValveInspectionEventSubscriber> _logger;

    public ValveInspectionEventSubscriber(
        ISalesforcePubSubService pubSubService,
        ILogger<ValveInspectionEventSubscriber> logger)
    {
        _pubSubService = pubSubService;
        _logger = logger;
    }

    [Function(nameof(ValveInspectionEventSubscriber))]
    public async Task RunAsync(
        [TimerTrigger("%SalesforceSubscriberSchedule%", RunOnStartup = true)] TimerInfo timer,
        CancellationToken cancellationToken)
    {
        _logger.LogInformation("Starting Salesforce valve-inspection event subscriber at {Timestamp}", DateTimeOffset.UtcNow);
        await _pubSubService.SubscribeAsync(cancellationToken);
    }
}
