using System.Text.Json.Serialization;

namespace GasSalesforceMaximoAppointment.Models;

public sealed record SalesforceTokenResponse(
    [property: JsonPropertyName("access_token")] string AccessToken,
    [property: JsonPropertyName("instance_url")] string InstanceUrl,
    [property: JsonPropertyName("issued_at")] string? IssuedAt,
    [property: JsonPropertyName("signature")] string? Signature);
