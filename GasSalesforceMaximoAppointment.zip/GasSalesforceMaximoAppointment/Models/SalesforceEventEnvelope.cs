namespace GasSalesforceMaximoAppointment.Models;

public sealed record SalesforceEventEnvelope(
    string EventId,
    string EventUuid,
    string ReplayId,
    string SchemaId,
    string ChannelName,
    string CorrelationId,
    DateTimeOffset ReceivedAtUtc,
    IReadOnlyDictionary<string, object?> Payload);
