# Gas Salesforce Maximo Valve Inspection

.NET 8 isolated Azure Function App that subscribes to Salesforce platform event
`/event/NG_Appointment_Event__e`, decodes the Apache Avro payload, publishes a durable JSON envelope to Azure Service Bus, checkpoints the replay ID in Azure Blob Storage, and sends the valve-inspection payload to Maximo.

## Hosting requirement

Deploy the subscriber to Azure Functions Premium or Dedicated hosting with at least one always-ready instance. The timer invocation intentionally remains active for the lifetime of the Salesforce gRPC subscription. `functionTimeout` is unlimited in `host.json`.

## Required Azure RBAC for the Function managed identity

- `Azure Service Bus Data Sender` on the topic/namespace
- `Azure Service Bus Data Receiver` on the subscription/namespace
- `Storage Blob Data Contributor` on the replay storage account
- `Key Vault Secrets User` when settings use Key Vault references

## Configuration

Copy the keys in `local.settings.json` into Function App environment variables. Replace every placeholder. Store secrets in Key Vault and expose them to the app using Key Vault references.

The Service Bus trigger uses identity-based configuration:

```text
ServiceBusConnection__fullyQualifiedNamespace=YOUR-NAMESPACE.servicebus.windows.net
```

`SalesforceSubscriberSchedule` is set to every five minutes. Timer triggers do not run overlapping invocations for the same Function; the active invocation keeps the gRPC stream open, and a new invocation starts after an unexpected clean exit or host restart.

## Salesforce authentication

The implementation uses OAuth 2.0 Client Credentials. Configure the External Client App with the `api` scope and a dedicated Run As integration user. Use the sandbox My Domain token endpoint, not the Salesforce Setup URL.

## Maximo mapping

`MaximoService` currently posts the decoded Salesforce event payload as JSON. When the Maximo request contract is available, add a mapper and replace `JsonContent.Create(valveInspectionEvent.Payload)` with the mapped Maximo model.

## Local build

```bash
dotnet restore
dotnet build --configuration Release
```

Local identity access uses `DefaultAzureCredential`; sign in with Azure CLI or Visual Studio before running.

## Deployment

```bash
func azure functionapp publish YOUR-FUNCTION-APP-NAME --dotnet-isolated
```

## Reliability behavior

- The replay ID is saved only after Service Bus accepts the event.
- Salesforce `EventUuid` becomes Service Bus `MessageId`; enable duplicate detection on the topic.
- Retryable Maximo responses throw and are retried by Service Bus.
- Non-retryable Maximo 4xx responses are dead-lettered.
- A failed Pub/Sub stream reconnects with exponential backoff and resumes from Blob Storage.
